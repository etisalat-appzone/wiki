<?php


function logFileSMS($rtn){
	$f=fopen("logs/loggerSMS.txt","a+");
	fwrite($f, $rtn . "\n");
	fclose($f);
}

function logFileSMSDelivery($rtn){
	$f=fopen("logs/loggerSMSDelivery.txt","a+");
	fwrite($f, $rtn . "\n");
	fclose($f);
}