<?php
/**
 *   (C) Copyright 1997-2013 hSenid International (pvt) Limited.
 *   All Rights Reserved.
 *
 *   These materials are unpublished, proprietary, confidential source code of
 *   hSenid International (pvt) Limited and constitute a TRADE SECRET of hSenid
 *   International (pvt) Limited.
 *
 *   hSenid International (pvt) Limited retains all title to and intellectual
 *   property rights in these materials.
 */
date_default_timezone_set('Asia/Colombo');
$date = date('m/d/Y h:i:s a', time());

include_once 'libs/SmsReceiver.php';
include_once 'libs/SmsSender.php';
include_once 'libs/logger.php';
ini_set('error_log', 'logs/sms-app-error.txt');

try {
    $receiver = new SmsReceiver(); // Create the Receiver object

    $content = $receiver->getMessage(); // get the message content
    $address = $receiver->getAddress(); // get the sender's address
    $requestId = $receiver->getRequestID(); // get the request ID
    $applicationId = $receiver->getApplicationId(); // get application ID
    $encoding = $receiver->getEncoding(); // get the encoding value
    $version = $receiver->getVersion(); // get the version

    logFileSMS("[ $date ][ content=$content, address=$address, requestId=$requestId, applicationId=$applicationId, encoding=$encoding, version=$version ]");

    $responseMsg;

    //your logic goes here......
    	
	$responseMsg="[ $date ]$content - Thank you ";

    // Create the sender object server url
    //$sender = new SmsSender("https://localhost:7443/sms/send");
	$sender = new SmsSender("http://dev.appzone.lk:7000/sms/send");
	
	
    //sending a one message

 	$applicationId = "APP_000097";
 	
 	
    $password = "edc6a2f2be43c7dd24d7d805b3cb7242";
    $sourceAddress = "4499";
   
    //$charging_amount = ":15";
    //$destinationAddresses = array("tel:94721122336");
	$destinationAddresses = array($address);
    $binary_header = "";
    $res = $sender->sms($responseMsg, $destinationAddresses, $password, $applicationId, $sourceAddress, $deliveryStatusRequest, $charging_amount, $encoding, $version, $binary_header);

} catch (SmsException $ex) {
    //throws when failed sending or receiving the sms
    error_log("ERROR: {$ex->getStatusCode()} | {$ex->getStatusMessage()}");
}



?>
